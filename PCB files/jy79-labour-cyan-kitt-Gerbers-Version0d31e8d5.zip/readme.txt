Project Name: Labour Cyan KITT
Project Version: #0d31e8d5
Project Url: https://www.flux.ai/jy79/labour-cyan-kitt

Project Description:
Smart Temperature controlled circuit


