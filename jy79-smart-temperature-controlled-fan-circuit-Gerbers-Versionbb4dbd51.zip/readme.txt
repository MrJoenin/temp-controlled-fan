Project Name: Smart Temperature controlled Fan circuit
Project Version: #bb4dbd51
Project Url: https://www.flux.ai/jy79/smart-temperature-controlled-fan-circuit

Project Description:
Smart Temperature controlled circuit


